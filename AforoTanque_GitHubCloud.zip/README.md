# AforoTanque — Android

Calculadora offline para un tanque cilíndrico horizontal.

Valores iniciales:
- Diámetro: 200 cm
- Largo: 300 cm
- Capacidad aproximada: 9424.78 litros

La fórmula calcula el área del segmento circular correspondiente a la altura del líquido y la multiplica por el largo.

## Compilar
Abrir la carpeta en Android Studio y sincronizar Gradle. Luego:
Build > Build APK(s)

Requisitos del proyecto:
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- compileSdk 35
- minSdk 23
