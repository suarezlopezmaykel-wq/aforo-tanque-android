package com.ejemplo.aforotanque

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.acos
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var diameter: EditText
    private lateinit var length: EditText
    private lateinit var level: EditText
    private lateinit var result: TextView
    private lateinit var percent: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Calculadora de aforo"
            textSize = 28f
            setPadding(0, 0, 0, 24)
        }
        layout.addView(title)

        layout.addView(label("Diámetro del tanque (cm)"))
        diameter = field("200")
        layout.addView(diameter)

        layout.addView(label("Largo del tanque (cm)"))
        length = field("300")
        layout.addView(length)

        layout.addView(label("Altura del líquido (cm)"))
        level = field("0")
        layout.addView(level)

        val button = Button(this).apply {
            text = "CALCULAR"
            setOnClickListener { calculate() }
        }
        layout.addView(button)

        result = TextView(this).apply {
            textSize = 22f
            setPadding(0, 28, 0, 8)
        }
        layout.addView(result)

        percent = TextView(this).apply {
            textSize = 18f
        }
        layout.addView(percent)

        val note = TextView(this).apply {
            text = "\nTanque cilíndrico horizontal. Funciona sin Internet."
            textSize = 15f
        }
        layout.addView(note)

        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setPadding(0, 12, 0, 4)
    }

    private fun field(value: String) = EditText(this).apply {
        setText(value)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        textSize = 18f
    }

    private fun calculate() {
        val d = diameter.text.toString().replace(',', '.').toDoubleOrNull()
        val l = length.text.toString().replace(',', '.').toDoubleOrNull()
        val h = level.text.toString().replace(',', '.').toDoubleOrNull()

        if (d == null || l == null || h == null || d <= 0 || l <= 0 || h < 0 || h > d) {
            result.text = "Revisa los valores introducidos."
            percent.text = ""
            return
        }

        val r = d / 2.0
        val area = r*r*acos((r-h)/r) - (r-h)*sqrt(2*r*h-h*h)
        val volumeCm3 = area * l
        val liters = volumeCm3 / 1000.0
        val totalLiters = Math.PI * r * r * l / 1000.0
        val pct = liters / totalLiters * 100.0

        result.text = "Volumen: %.2f litros".format(liters)
        percent.text = "Llenado: %.2f %%\nCapacidad máxima: %.2f litros".format(pct, totalLiters)
    }
}
