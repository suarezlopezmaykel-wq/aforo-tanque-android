# AforoTanque — compilación en la nube

1. Crea un repositorio nuevo en GitHub.
2. Sube todos los archivos de esta carpeta al repositorio.
3. En GitHub abre **Actions**.
4. Ejecuta **Compilar APK**.
5. Al terminar, abre la ejecución y descarga el artefacto **AforoTanque-debug**.
6. Dentro encontrarás `app-debug.apk`, que puedes instalar en Android.

La primera versión funciona sin Internet y calcula el volumen de un tanque cilíndrico horizontal.
